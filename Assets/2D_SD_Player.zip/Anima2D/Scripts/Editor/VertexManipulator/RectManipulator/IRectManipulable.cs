﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace Anima2D
{
	public interface IRectManipulable
	{
		IRectManipulatorData rectManipulatorData { get; }
	}
}
